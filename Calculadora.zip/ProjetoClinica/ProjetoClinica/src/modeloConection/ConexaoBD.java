package modeloConection;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import modeloBeans.BeansMedico;
import org.firebirdsql.jdbc.FBDriver;

public class ConexaoBD {
    
    public Statement stm;
    public ResultSet rs;
    private String driver = "org.firebirdsql.jdbc.FBDriver";
    private String caminho = "jdbc:firebirdsql://localhost:3050/C:/Testes/CLINICA.FDB";
    private String usuario = "sysdba";
    private String senha = "cinco.25";
    public Connection con;
    
    public void conexao() {
        
        
        try {
            System.setProperty("jdbc.Drivers", driver);
            
            con = DriverManager.getConnection(caminho, usuario, senha);
             //JOptionPane.showMessageDialog(null, "conexão efetuada com sucesso");
        } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Erro ao se conectar com banco de dados\n"+ ex.getMessage());
        }
    }
      
    public void desconecta(){
           try {
               con.close();
               //JOptionPane.showMessageDialog(null, "BD desconectado com sucesso");
           } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Erro ao fechar banco de Dados\n"+e.getMessage());
           }
       }
        
    
    
    public void executaSql(String sql){
        try {
            //JOptionPane.showMessageDialog(null, sql);
            stm = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE, rs.CONCUR_READ_ONLY);
            rs = stm.executeQuery(sql);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro executa SQL./nERRO: "+ex);
        }
    }
        
        
//        try {
//            Class.forName(driver);
//            con = DriverManager.getConnection(caminho, usuario, senha);
//            
//            JOptionPane.showMessageDialog(null, "Conexão realizada com sucesso");
//        } catch (ClassNotFoundException ex) {
//            JOptionPane.showMessageDialog(null, "Driver nao localizado", "Erro", 0);
//        } catch (Exception ex) {
//            JOptionPane.showMessageDialog(null, "ERRO AO CONECTAR COM SERVIDOR FIREBIRD", "ATENÇÃO", (2));
//
//        }
//        return con;
//    }
//    
//    public static void main(String[] args) {
//        new ConexaoBD().conexao();

    //Statement createStatement(int TYPE_SCROLL_SENSITIVE, int CONCUR_UPDATABLE) {
    //    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    //}

    
}


