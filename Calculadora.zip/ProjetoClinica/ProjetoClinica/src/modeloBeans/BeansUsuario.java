

package modeloBeans;


public class BeansUsuario {
        
    private Integer usuCod;
    private String usuUsu;
    private String usuNome;
    private String usuTipo;
    private String usuSenha;
    private String usuPesquisa;
    
    
    
    public Integer getUsuCod(){
        return this.usuCod;
    }
    
    public void setUsuCod(Integer usuCod){
        this.usuCod = usuCod;
    }
    

    public String getUsuUsu() {
        return usuUsu;
    }

    public void setUsuUsu(String usuUsu) {
        this.usuUsu = usuUsu;
    }

    /**
     * @return the usuNome
     */
    public String getUsuNome() {
        return usuNome;
    }

    /**
     * @param usuNome the usuNome to set
     */
    public void setUsuNome(String usuNome) {
        this.usuNome = usuNome;
    }

    /**
     * @return the usuTipo
     */
    public String getUsuTipo() {
        return usuTipo;
    }

    /**
     * @param usuTipo the usuTipo to set
     */
    public void setUsuTipo(String usuTipo) {
        this.usuTipo = usuTipo;
    }

    /**
     * @return the usuSenha
     */
    public String getUsuSenha() {
        return usuSenha;
    }

    /**
     * @param usuSenha the usuSenha to set
     */
    public void setUsuSenha(String usuSenha) {
        this.usuSenha = usuSenha;
    }

    /**
     * @return the pesquisa
     */
    public String getUsuPesquisa() {
        return usuPesquisa;
    }

    /**
     * @param usuPesquisa the pesquisa to set
     */
    public void setUsuPesquisa(String usuPesquisa) {
        this.usuPesquisa = usuPesquisa;
    }
    
    
}
