
package modeloDao;
import modeloConection.ConexaoBD;
import java.sql.*;


public class Codigos {
    ConexaoBD conex = new ConexaoBD();
    private int codMedico;
    
    //private int codMedico =  (conex.stm.("select codigo from codigos where codigos.tabelas = 'COD_MEDICO'"));
    
    //Connection stmt = conex.stm.execute("select codigo from codigos where codigos.tabelas = 'COD_MEDICO'");
    ResultSet rs;  

    public Codigos() throws SQLException {
        
        // = stmt.executeQuery("select codigo from codigos where codigos.tabelas = 'COD_MEDICO'");
        //this.codMedico = rs;
        //rs.
    }
            

    //conex. "select codigo from codigos where codigos.tabelas = 'COD_MEDICO'");
     

    public int getCodMedico() {
        return codMedico;
    }

    public void setCodMedico(int codMedico) {
        this.codMedico += 1;
    }
}
