/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloDao;

import modeloConection.ConexaoBD;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import modeloBeans.BeansMedico;
import org.firebirdsql.gds.ng.StatementState;


public class DaoMedico {
    //Codigos cod = new Codigos();
    ConexaoBD conex = new ConexaoBD();
    BeansMedico mod = new BeansMedico();
    
    //salvar os dados do usuarios
    
    public void salvar(BeansMedico mod){
        conex.conexao();
        try {
            PreparedStatement pst = conex.con.prepareStatement("insert into medicos(nome_medico, especialidade_medico, crm_medico) values (?,?,?)");
            //pst.setInt(1, mod.getCodigo()); //Controle de CODIGO MEDICO
            pst.setString(1, mod.getNome());
            pst.setString(2, mod.getEspecialidade());
            pst.setInt(3, mod.getCrm());
            pst.execute();
            
            //mod.setCodigo(1);
            JOptionPane.showMessageDialog(null, "Foi salvo com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar os dados/nERRO: "+ex);
        }
        
        
        conex.desconecta();   
    }
    
    
    //Alterar e gravar os dados do usuario
    public void editar(BeansMedico mod){
        conex.conexao();
        
        try {
            
            PreparedStatement pst = conex.con.prepareStatement("update medicos set nome_medico=?, especialidade_medico=?, crm_medico=? where cod_medico=?");
            pst.setString(1, mod.getNome());
            pst.setString(2, mod.getEspecialidade());
            pst.setInt(3, mod.getCrm());
            pst.setInt(4, mod.getCodigo());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Dados alterado com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro ao alterar os dados/nErro: "+ ex);
        }
              
        conex.desconecta();
    }
    
    //Excluir os dados da pessoa do sistema
    
    public void Excluir(BeansMedico mod){
        try {
            conex.conexao();
            PreparedStatement pst = conex.con.prepareStatement("delete from medicos where cod_medico =?");
            pst.setInt(1, mod.getCodigo());
            pst.execute();
            
            JOptionPane.showMessageDialog(null, "Dados excluidos com sucesso!");
                      
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro excluir dados /nERRO: "+ex);
        }
        conex.desconecta();        
    }
    
    
    //Pesquisa de pessoas por busca
    public BeansMedico buscaMedico(BeansMedico mod){
        conex.conexao();
        conex.executaSql("select * from medicos where medicos.nome_medico like'%"+mod.getPesquisa()+"%'");
         
        try {
            conex.rs.first();
            mod.setCodigo(conex.rs.getInt("cod_medico"));
            mod.setNome(conex.rs.getString("nome_medico"));
            mod.setEspecialidade(conex.rs.getString("especialidade_medico"));
            mod.setCrm(conex.rs.getInt("crm_medico"));
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Medico não cadastrado");
        }
        
        conex.desconecta();
        return mod;
    }
}
