

package modeloDao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import modeloBeans.BeansUsuario;
import modeloConection.ConexaoBD;


public class DaoUsuario {
    //Codigos cod = new Codigos();
    ConexaoBD conex = new ConexaoBD();
    BeansUsuario mod = new BeansUsuario();
    
    
    //salvar os dados do usuarios
    
    public void salvar(BeansUsuario mod){
        conex.conexao();
        try {
            PreparedStatement pst = conex.con.prepareStatement("insert into usuarios(usu_usu, usu_nome, usu_senha, usu_tipo) values (?,?,?,?)");
            //pst.setInt(1, mod.getCodigo()); //Controle de CODIGO MEDICO
            pst.setString(1, mod.getUsuUsu());
            pst.setString(2, mod.getUsuNome());
            pst.setString(3, mod.getUsuSenha());
            pst.setString(4, mod.getUsuTipo());
            pst.execute();
            
            //mod.setCodigo(1);
            JOptionPane.showMessageDialog(null, "Usuario Inserido com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao Inserir Usuario/nERRO: "+ex);
        }
        
        
        conex.desconecta();   
    }
    
    
    //Alterar e gravar os dados do usuario
    public void Altera(BeansUsuario mod){
        conex.conexao();
        
        try {
            PreparedStatement pst = conex.con.prepareStatement("update usuarios set usu_usu=?, usu_nome=?, usu_tipo=? where usu_cod=?");
            pst.setString(1, mod.getUsuUsu());
            pst.setString(2, mod.getUsuNome());
            pst.setString(3, mod.getUsuTipo());
            pst.setInt(4, mod.getUsuCod());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Usuario alterado com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro ao alterar o Usuario/nErro: "+ ex);
        }
              
        conex.desconecta();
    }
    
    //Excluir os dados da pessoa do sistema
    
    public void Excluir(BeansUsuario mod){
        try {
            conex.conexao();
            PreparedStatement pst = conex.con.prepareStatement("delete from usuarios where usu_cod =?");
            pst.setInt(1, mod.getUsuCod());
            pst.execute();
            
            JOptionPane.showMessageDialog(null, "Dados excluidos com sucesso!");
                      
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro excluir dados /nERRO: "+ex);
        }
        conex.desconecta();        
    }
    
    
    //Pesquisa de pessoas por busca
    public BeansUsuario BuscaUsuario(BeansUsuario mod){
        conex.conexao();
        conex.executaSql("select * from usuarios where usuarios.usu_usu like'%"+mod.getUsuPesquisa()+"%'");
         
        try {
            conex.rs.first();
            mod.setUsuCod(conex.rs.getInt("usu_cod"));
            mod.setUsuUsu(conex.rs.getString("usu_usu"));
            mod.setUsuNome(conex.rs.getString("usu_nome"));
            mod.setUsuTipo(conex.rs.getString("usu_tipo"));
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Usuario não encontrado");
        }
        
        conex.desconecta();
        return mod;
    }
    
}
